TEACHING KIT — Slide Vault
==============================================

4 editable PowerPoint templates, free for personal and commercial use.
No signup, no watermark, no attribution required.

IN THIS BUNDLE (suggested order)
  1. Lesson Plan Template                                  Lesson-Plan-Template.pptx
     https://slidevaulte.com/templates/lesson-plan-template/
  2. Workshop Presentation Template                        Workshop-Presentation-Template.pptx
     https://slidevaulte.com/templates/workshop-presentation-template/
  3. Training Course Template                              Training-Course-Template.pptx
     https://slidevaulte.com/templates/training-course-template/
  4. Academic Defense Template                             Academic-Defense-Template.pptx
     https://slidevaulte.com/templates/academic-defense-template/

EDITING
  Every file is a plain .pptx built from standard shapes and text boxes.
  Opens in PowerPoint, Google Slides and Keynote. Change colours through
  Design > Variants > Colors; replace images with right-click > Change Picture.

BEFORE YOU SHARE
  These layouts ship with speaker notes and document properties. Strip them
  with the free browser tools at https://slidevaulte.com/tools/ (nothing is uploaded).

MORE FREE DECKS
  https://slidevaulte.com/#templates

Slide Vault · https://slidevaulte.com
